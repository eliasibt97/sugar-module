<?php

require_once('isies_math_sugar.php');

class isies_math extends isies_math_sugar {

    public function __construct()
    {
        parent::__construct();
    }
}

?>