<?php

    $mod_strings = [
        'LBL_NUMERO_UNO' => 'Number 1',
        'LBL_NUMERO_DOS' => 'Number 2',
        'LBL_RESULTADO' => 'Result',
        'LBL_TIPO' => 'Type',
    ];

?>