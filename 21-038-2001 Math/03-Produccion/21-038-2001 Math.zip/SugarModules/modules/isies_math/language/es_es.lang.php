<?php

    $mod_strings = [
        'LBL_NUMERO_UNO' => 'Numero 1',
        'LBL_NUMERO_DOS' => 'Numero 2',
        'LBL_RESULTADO' => 'Resultado',
        'LBL_TIPO' => 'Tipo',
    ];

?>