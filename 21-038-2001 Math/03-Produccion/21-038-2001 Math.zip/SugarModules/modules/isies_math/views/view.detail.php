<?php

require_once 'include/MVC/View/views/view.detail.php';

class isies_prueba_moduloViewDetail extends ViewDetail
{
    public function displayJavascript()
    {
        parent::displayJavascript();
    }

    function display() {
        return parent::display();
    }

}