<?php

$module_name = 'isies_math';
$listViewDefs[$module_name] = [
    'NUMERO_UNO' => [
        'width' => '25',
        'label' => 'LBL_NUMERO_UNO',
        'dafault' => true,
        'link' => true
    ],
    'NUMERO_DOS' => [
        'width' => '25',
        'label' => 'LBL_NUMERO_DOS',
        'dafault' => true,
        'link' => true
    ],
    'RESULTADO' => [
        'width' => '25',
        'label' => 'LBL_RESULTADO',
        'dafault' => true,
        'link' => true
    ],
    'TIPO' => [
        'width' => '25',
        'label' => 'LBL_TIPO',
        'dafault' => true,
        'link' => true
    ],
];

?>