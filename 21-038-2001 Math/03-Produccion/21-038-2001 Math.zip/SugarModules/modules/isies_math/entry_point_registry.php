<?php

    $entry_point_registry['list']= ['file' => 'modules/isies_math/backend/MathOrchester.php', 'auth' => false];

?>