<?php
$admin_option_defs = array();
$admin_option_defs['Administration']['config_math'] = array('ConfigureSubPanels', 'Calculadora', 'Haga cálculos rápidos', './index.php?module=isies_config_math&action=index');
$admin_group_header[] = array('Math','', false, $admin_option_defs,'Calculadora Exprés');
?>