<?php

function post_install() {
    
    require_once('data/MathBean.php');
    $bean = new MathBean();
    $mode = $_POST['mode'];

    switch ($mode) {
        case 'install':
            global $db;
            $db->query($bean->install());
            break;
            
        case 'uninstall':
            global $db;
            $db->query($bean->uninstall());
            break;
            
        default:
           throw "Not action allowed";
            break;
    }
    


}

?>